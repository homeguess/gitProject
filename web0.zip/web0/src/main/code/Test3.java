import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by jun on 16/7/2.
 */
@Controller
@RequestMapping("/hello")
public class Test3 {

    @Autowired
    private UserMapper userMapper;
    @RequestMapping("/index")
    public ModelAndView index(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ModelAndView modelView = new ModelAndView();
        modelView.addObject("msg","Hello Index");
        List<String> list = new ArrayList<String>(Arrays.asList("ff","a","fser","fff"));
        modelView.addObject("list0",list);
        modelView.setViewName("index");
        System.err.println("执行index！");
//        response.getWriter().write("66666");
        User user = new User();
        user.setId("24234334");
        user.setPwd("5234234");
//        userMapper.add(user);
        return modelView;
    }
}
