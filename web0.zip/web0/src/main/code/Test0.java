import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import java.io.IOException;

/**
 * Created by jun on 16/6/27.
 */
@WebServlet(name = "Test0",urlPatterns = "/test")
public class Test0 extends HttpServlet{
    @Autowired
    private UserMapper userMapper;
    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
        try {
            response.getWriter().write("1111");
            User user = new User();
            user.setId("2222");
            user.setPwd("333");
            userMapper.add(user);
            System.out.print("插入条信息入去如何?");
        }catch (IOException e){
            System.out.print(e.getCause());
        }
    }

}
