import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

/**
 * Created by jun on 16/6/28.
 */
@Component
public interface UserMapper {

    @Insert("insert into users(pwd) values(#{pwd})")
    int add(User user);

    @Delete("delete from users where id =#{id}")
    int deleteById(int id);

}
