import java.io.*;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;

/**
 * Created by jun on 16/7/21.
 */
public class TestProxyIp {
	private String filePath = "/Users/jun/ip.txt";

	private String filePath0 = "/Users/jun/itemInfo.txt";

	public static void main(String[] args) {
		try {
			new TestProxyIp();
		} catch (IOException e) {
			e.printStackTrace();
		}
//        System.out.print(TestProxyConnectTime("http://www.taobao.com","113.111.149.191",9999));
	}

	public TestProxyIp() throws IOException {
		File file = new File(filePath0);
		Long filelength = file.length();
		byte[] filecontent = new byte[filelength.intValue()];
		FileInputStream in = new FileInputStream(file);
		in.read(filecontent);
		in.close();
		String value = new String(filecontent);
//		HashMap<String, String> ipMap = JSON.parseObject(value, new TypeReference<HashMap<String, String>>() {
//		});
		HashMap<String, String> ipMap = JSON.parseObject(value, new TypeReference<HashMap<String, String>>() {
		});

		HashMap<String, String> ipMap0 = JSON.parseObject(ipMap.get("defaultModel"),
				new TypeReference<HashMap<String, String>>() {
				});

		HashMap<String, String> ipMap1 = JSON.parseObject(ipMap0.get("itemPriceResultDO"),
				new TypeReference<HashMap<String, String>>() {
				});

		HashMap<String, String> ipMap2 = JSON.parseObject(ipMap1.get("priceInfo"),
				new TypeReference<HashMap<String, String>>() {
				});
		for (Map.Entry<String, String> entry : ipMap.entrySet()) {

		}

	}

	public static long TestProxyConnectTime(String url, String proxyHost, int proxyPort) {
		OutputStreamWriter out = null;
		BufferedReader in = null;
		String result = "";
		long costTime = 0;
		try {
			URL realUrl = new URL(url);
			HttpURLConnection conn = null;

			@SuppressWarnings("static-access")
			Proxy proxy = new Proxy(Proxy.Type.DIRECT.HTTP, new InetSocketAddress(proxyHost, proxyPort));
			conn = (HttpURLConnection) realUrl.openConnection(proxy);

			// 打开和URL之间的连接

			// 发送POST请求必须设置如下两行
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setRequestMethod("GET"); // POST方法

			// 设置通用的请求属性

			conn.setRequestProperty("accept", "*/*");
			conn.setRequestProperty("connection", "Keep-Alive");
			conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

			costTime = System.currentTimeMillis();
			conn.connect();
			costTime = System.currentTimeMillis() - costTime;
			// 获取URLConnection对象对应的输出流
//			out = new OutputStreamWriter(conn.getOutputStream(), "UTF-8");
			// 发送请求参数
//			out.write(param);
			// flush输出流的缓冲
//			out.flush();
			// 定义BufferedReader输入流来读取URL的响应
//            in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
//            String line;
//            while ((line = in.readLine()) != null) {
//                result += line;
//            }
		} catch (Exception e) {
			System.out.println("发送 POST 请求出现异常！" + e);
			e.printStackTrace();
		}
//        System.out.print(result);
		return costTime;
	}
}
