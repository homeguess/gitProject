import com.gargoylesoftware.htmlunit.*;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.util.Cookie;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

/**
 * Created by jun on 16/6/28.
 */
public class Test2 {
    public static void main(String[] args) throws IOException {
//        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
//        UserMapper userMapper = (UserMapper) context.getBean(UserMapper.class);
//        User user = new User();
//        user.setPwd("333");
//        userMapper.add(user);
//        System.out.print(user.getId());

        //URL link=new URL("http://pub.alimama.com/");
        URL link = new URL("http://pub.alimama.com/");
        WebRequest request = new WebRequest(link);
        WebClient webClient = new WebClient();
        webClient.getOptions().setCssEnabled(false);
        webClient.getCookieManager().setCookiesEnabled(true);
        webClient.getOptions().setRedirectEnabled(true);
//        webClient.setJavaScriptTimeout(10000);
        webClient.getOptions().setJavaScriptEnabled(false);
        HashMap<String,String> headMap = new HashMap<>();
        headMap.put("User-Agent","Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0");
        headMap.put("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8,application/json, text/javascript, */*; q=0.01");
        headMap.put("Accept-Language","zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3");
        headMap.put("Accept-Encoding","gzip, deflate");
        headMap.put("X-Requested-With","XMLHttpRequest");
        headMap.put("Referer","http://pub.alimama.com/promo/search/index.htm?q=https%3A%2F%2Fitem.taobao.com%2Fitem.htm%3Fid%3D26103664179%26ali_refid%3Da3_420434_1006%3A1104265159%3AN%3A%25E5%2598%2589%25E5%25A8%259C%25E5%25AE%259D%3Aeb20a4e0753110b172fc3aec1b921584%26ali&_t=1469002603887");
        headMap.put("Connection","keep-alive");
        request.setAdditionalHeaders(headMap);
        request.setHttpMethod(HttpMethod.GET);
        HtmlPage page =  webClient.getPage(request);
        String content = page.asText();
        String cookie2 = webClient.getCookieManager().getCookie("cookie2").getValue();


        link = new URL("https://login.taobao.com/member/login.jhtml?style=mini&newMini2=true&from=alimama&redirectURL=http%3A%2F%2Flogin.taobao.com%2Fmember%2Ftaobaoke%2Flogin.htm%3Fis_login%3d1&full_redirect=true&disableQuickLogin=true");
        request.setUrl(link);
        page =  webClient.getPage(request);
        String tbToken = webClient.getCookieManager().getCookie("_tb_token_").getValue();

        String domain = "pub.alimama.com";
//        link = new URL("https://login.taobao.com/member/login.jhtml?style=mini&newMini2=true&from=alimama&redirectURL=http%3A%2F%2Flogin.taobao.com%2Fmember%2Ftaobaoke%2Flogin.htm%3Fis_login%3d1&full_redirect=true&disableQuickLogin=true");
        link = new URL("http://pub.alimama.com/common/code/getAuctionCode.json?auctionid=3871509989&adzoneid=58662416&siteid=15192068&scenes=1&t=1469091883765&_tb_token_="+tbToken+"&pvid=10_116.22.232.73_384_1469091876355");
        request.setUrl(link);
        webClient.getCookieManager().addCookie(new Cookie(domain,"cookie2",cookie2));
        UnexpectedPage unexpectedPage =  webClient.getPage(request);
        content = unexpectedPage.getWebResponse().getContentAsString();
        System.out.print(content);
    }
}
