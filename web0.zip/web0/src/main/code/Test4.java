import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.processor.PageProcessor;

/**
 * Created by jun on 16/8/5.
 */
public class Test4 implements PageProcessor {
	public static void main(String[] args) throws IOException {
//		Spider.create(new Test4()).addUrl(
//				"https://detailskip.taobao.com/service/getData/1/p2/item/detail/sib.htm?itemId=526408195335&modules=qrcode,viewer,price,contract,duty,xmpPromotion,dynStock,delivery,upp,sellerDetail,activity,fqg,zjys,coupon&callback=onSibRequestSuccess") // 开始地址
//				.addPipeline(new ConsolePipeline()) // 打印到控制台
//				.thread(5) // 开启5线程
//				.run();

//		String itemInfo = ""

//		String tmp = "\nsetMdskip\n({a:123412312314123,(sdfsdaf)})";
//		String rep = "\nsetMdskip\n\\((.+)\\)";

//		String tmp o= "https://detail.tmall.com/item.htm?id=53433spm=a220m.1000858.1000725.22.2dU2ou?sid=3343434&cat_id=50032140id=529397857693&skuId=3153495609268&cat_id=50032140&rn=84fa454c7471659ad978051b03d175bb&user_id=202271589&is_b=1";
//		String rep = "https://detail.tmall.com/item.htm.*?[?&]id=(\\d+).*";
//		String tmp = "fasdfdsfsdfsChina=1_China=2";
//		String rep = "^China$=(\\d+)";

		String tmp = "https://detail.tmall.com/item.htm?id=18628468375&rn=9247e3b1c9598c6c8217256ee53f2a51&abbucket=0";
		String rep = "https://detail.tmall.com/item.htm?.*?[?&]id=(\\d+).*";
		Pattern compile = Pattern.compile(rep);
		boolean m0 = compile.matcher(tmp).matches();
		System.out.print(m0);
		Matcher m = compile.matcher(tmp);
		while (m.find()) {
			System.out.print(m.group(1));
		}
	}

	@Override
	public void process(Page page) {
		System.out.println(page.getRawText());
	}

	private Site site = Site.me().setSleepTime(1000).setRetryTimes(3);

	@Override
	public Site getSite() {
		return site;
	}
}
