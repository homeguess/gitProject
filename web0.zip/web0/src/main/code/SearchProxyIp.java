import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.jetty.util.StringUtil;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.gargoylesoftware.htmlunit.TextPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlTableDataCell;

/**
 * Created by jun on 16/7/20.
 */
public class SearchProxyIp {
	private String filePath = "/Users/jun/ip.txt";

	private WebClient webClient;

	private HashMap<String, String> ipHash;
	// 大于1秒
	private long verifyTime = 1000;

	private String testWebSite = "www.taobao.com";

	public SearchProxyIp() throws IOException {
		webClient = new WebClient();
		webClient.getOptions().setCssEnabled(false);
		webClient.getCookieManager().setCookiesEnabled(true);
		webClient.getOptions().setRedirectEnabled(true);
		webClient.getOptions().setJavaScriptEnabled(false);

//		ipHash = new HashMap<>();
//
//		try {
//			for (int page = 1; page < Integer.MAX_VALUE; page++) {
//				searchHash(page);
//			}
//		} catch (IOException e) {
//			e.printStackTrace();
//		} finally {
//			try {
//				save();
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}

		searchHash(0);

	}

	private void searchHash(int page) throws IOException {
//        URL link = new URL("http://www.kuaidaili.com/proxylist/"+String.valueOf(page)+"/");
//		URL link = new URL(
//			"https://detailskip.taobao.com/service/getData/1/p2/item/detail/sib.htm?itemId=532709502234&modules=qrcode,viewer,price,contract,duty,xmpPromotion,dynStock,delivery,upp,sellerDetail,activity,fqg,zjys,coupon&callback=onSibRequestSuccess");
		URL link = new URL(
				"https://detail.tmall.com/item.htm?spm=a220m.1000858.1000725.11.oU9Umb&id=531929523284&cat_id=50032140&rn=df487982f50b145abafcf2dd48ab8ff2&user_id=196993935&is_b=1");
		WebRequest request = new WebRequest(link);
		HashMap<String, String> headMap = new HashMap<>();
		headMap.put("Accept", "*/*");
		headMap.put("Host", "detailskip.taobao.com");
//		headMap.put("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0");
//		headMap.put("Accept-Language", "zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3");
//		headMap.put("Accept-Encoding", "gzip, deflate, br");
		headMap.put("Referer",
				"https://item.taobao.com/item.htm?spm=2013.1.0.0.TAr23I&scm=1007.10010.29847.100200300000001&id=532709502234&pvid=5b518844-01e4-4a00-b07a-559fdac0cb92");
//		headMap.put("Cookie", "t=65e8a0e71cbb538575aa8645ac86d4ba; thw=cn; cna=/X4XEIA6UWACAXQW6ElzBrKe; l=AqioA-P5CeFjoQBrvNFzN55DWJi5PwzF; isg=Ao2N2LsH5sjjoELQrsMzDekxn68bvME8WzqLCM8RJySNxqx4l7gMDbCeRuNb; mt=ci=17_1; uc3=nk2=BdwmI5lVhwLM5Q%3D%3D&id2=UU6lRfPd9Fnc&vt3=F8dAS1SBnjNN36dzgKo%3D&lg2=URm48syIIVrSKA%3D%3D; lgc=flyko_2009; tracknick=flyko_2009; _cc_=W5iHLLyFfA%3D%3D; tg=0; ucn=center; cookie2=1cec6ccd70d0c7095526d19d4751dffc; v=0; _tb_token_=e339e3aee1ee3; uc1=cookie14=UoWwJMogQxPWLg%3D%3D");
//		headMap.put("Connection", "keep-alive");
		request.setAdditionalHeaders(headMap);
//        request.setProxyHost("113.108.82.29");
//        request.setProxyPort(8080);
//        request.setHttpMethod(HttpMethod.GET);
//        request.setSocksProxy(true);
		System.out.print("requesting.....\n");
		TextPage textPage = webClient.getPage(request);
		System.out.print(textPage.getContent());
		HtmlPage htmlPage = null;

		List<HtmlTableDataCell> list = (List<HtmlTableDataCell>) htmlPage.getByXPath("//td[@data-title]");
		System.out.print("done\n");
		if (list.isEmpty()) {
			throw new IOException();
		}
		String key = StringUtils.EMPTY;
		for (HtmlTableDataCell htmlTableDataCell : list) {
			String type = htmlTableDataCell.asXml();
			if (StringUtil.isBlank(type)) {
				continue;
			}
			if (type.indexOf("IP") != -1) {
				key = htmlTableDataCell.getTextContent();
			} else if (type.indexOf("PORT") != -1) {
				ipHash.put(key, htmlTableDataCell.getTextContent());
				key = StringUtils.EMPTY;// reset
			}
		}
	}

	private void save() throws IOException {
//        testProxyTime();
		File file = new File(filePath);
		if (!file.exists()) {
			file.createNewFile();
		}
		FileWriter fw = new FileWriter(file.getAbsoluteFile());
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write(JSON.toJSONString(ipHash, SerializerFeature.PrettyFormat));
		bw.close();

		System.out.println("save ok");

	}

	private void testProxyTime() {
		for (Map.Entry<String, String> entry : ipHash.entrySet()) {
			if (TestProxyIp.TestProxyConnectTime(testWebSite, entry.getKey(),
					Integer.valueOf(entry.getValue())) > verifyTime) {
				ipHash.remove(entry.getKey());
			}
		}
	}

	public static void main(String[] args) throws IOException {
		new SearchProxyIp();
//		String site = "localhost:8080/user/eee/abc.html";
//
//		String regex = ":\\d+(/.*?)\\/";
//		Pattern compile = Pattern.compile(regex);
//		Matcher m = compile.matcher(site);
//		while (m.find()) {
////            System.out.print(m.group(1));
//		}
//
//		regex = "(/.*.html)";
//		compile = Pattern.compile(regex);
//		m = compile.matcher(site);
//		while (m.find()) {
//			System.out.print(m.group(1));
//		}

	}
}
