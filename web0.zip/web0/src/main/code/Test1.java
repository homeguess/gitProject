import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.gargoylesoftware.htmlunit.*;
import com.gargoylesoftware.htmlunit.html.*;
import com.gargoylesoftware.htmlunit.util.Cookie;
import com.gargoylesoftware.htmlunit.util.NameValuePair;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.util.EntityUtils;

/**
 * Created by jun on 16/6/28.
 */

public class Test1 {

    public static void main(String[] args) throws IOException {
//        String resource = "configuration.xml";
//        Reader reader = Resources.getResourceAsReader(resource);
//        SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(reader);
//        SqlSession session = sessionFactory.openSession();
//        UserMapper userMapper = session.getMapper(UserMapper.class);
//        User user = new User();
//        user.setId("1");
//        user.setPwd("123456");
//        userMapper.add(user);
//        userMapper.deleteById(1);
//        session.commit();
//        session.close();
//        "be1e68548d159ffcd61afd7964799964"
//        URL link11=new URL("http://www.alimama.com/");
//        WebRequest request11 = new WebRequest(link11);
//        WebClient webClient11 = new WebClient();
//        webClient11.getOptions().setRedirectEnabled(true);
//        request11.setHttpMethod(HttpMethod.GET);
//        HtmlPage page11 =  webClient11.getPage(request11);



        String userName = "xjacker";
        String pwd = "@upon.com";

        URL link=new URL("https://login.taobao.com/member/login.jhtml?redirectURL=http%3A%2F%2Flogin.taobao.com%2Fmember%2Ftaobaoke%2Flogin.htm%3Fis_login%3D1");
        WebRequest request = new WebRequest(link);
        WebClient webClient = new WebClient();
        webClient.getOptions().setCssEnabled(false);
        webClient.getCookieManager().setCookiesEnabled(true);
        webClient.getOptions().setRedirectEnabled(true);
        HashMap<String,String> headMap = new HashMap<>();
        headMap.put("User-Agent","Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0");
        headMap.put("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8,application/json, text/javascript, */*; q=0.01");
        headMap.put("Accept-Language","zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3");
        headMap.put("Accept-Encoding","gzip, deflate");
        headMap.put("X-Requested-With","XMLHttpRequest");
        headMap.put("Referer","http://pub.alimama.com/promo/search/index.htm?q=https%3A%2F%2Fitem.taobao.com%2Fitem.htm%3Fid%3D26103664179%26ali_refid%3Da3_420434_1006%3A1104265159%3AN%3A%25E5%2598%2589%25E5%25A8%259C%25E5%25AE%259D%3Aeb20a4e0753110b172fc3aec1b921584%26ali&_t=1469002603887");
        headMap.put("Connection","keep-alive");
        request.setAdditionalHeaders(headMap);
        List<NameValuePair> listParams = new ArrayList<>();
        listParams.add(new NameValuePair("TPL_password",pwd));
        listParams.add(new NameValuePair("TPL_username",userName));
        listParams.add(new NameValuePair("newlogin","0"));
        listParams.add(new NameValuePair("callback","1"));
        listParams.add(new NameValuePair("from","alimama"));
        listParams.add(new NameValuePair("keyLogin","false"));
        listParams.add(new NameValuePair("qrLogin","true"));
        listParams.add(new NameValuePair("loginType","3"));
        listParams.add(new NameValuePair("sr","1920*1080"));
        listParams.add(new NameValuePair("loginASR","1"));
        listParams.add(new NameValuePair("loginASRSuc","1"));
        listParams.add(new NameValuePair("slideCodeShow","false"));
        listParams.add(new NameValuePair("loginSite","0"));
        request.setRequestParameters(listParams);

//        String domain = "taobao.com";
//        webClient.getCookieManager().addCookie(new Cookie(domain,"_cc_","UIHiLt3xSw=="));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"_l_g_","Ug=="));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"_nk_",""));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"_uab_collina","146883227090538368909994"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"_umdata","0823A424438F76ABF9ECA0078FFA2C84F307FCE67DFFBEEF693CA03E5F9218D4F61DF7576C9A378CA25A7D7C1AC3EFEB6FA36032AA87F2E2AF5BE0A17FC63B86B8408E81CAECED9925B933E21E4999F0560C44E5EADF9789E3C3248DC97263DD0A6225010E2CCA26"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"cna","sIYTEF2XWG4CAXQW6RfWKi3q"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"cookie1","UIGlaoZD5ZVncOdx+dz6Y8b6N5Lo8d6gMSedu0ey4yg="));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"cookie17","UU6lRfPd9Fnc"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"existShop","MTQ2ODkxNDM2Mg=="));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"isg","AgoK4bg9achuX-VlXqOFkl19WPYvMY5VkNus4ZRDtt3oR6oBfIveZVA1IQpg"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"l","AqWlkpau26d5xj1cuSIGAYXflW/f4Vl0"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"lc","Vy6+6K2ZW1JjZNz4246e"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"lgc",""));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"lid",""));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"mt","np="));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"sg","957"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"skt","16be014c5c46e3b3"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"tg","0"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"thw","cn"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"tracknick",""));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"uc1","cookie14=UoWxOQL872Qvhw==&cookie16=W5iHLLyFPlMGbLDwA+dvAGZqLg==&existShop=false&cookie21=UIHiLt3xSi+tvZI3po03ig==&tag=2&cookie15=URm48syIIVrSKA==&pas=0"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"uc2","wuf=http://pub.alimama.com/"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"uc3","sg2=AVBbqgVtNuYVR621bdJBm31otBgKk9VdmK5iUSd1uwQ=&nk2=BdwmI5lVhwLM5Q==&id2=UU6lRfPd9Fnc&vt3=F8dAS1dj/levShHq/co=&lg2=URm48syIIVrSKA=="));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"unb","264860535"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"uss","WvjvNbq2ztpJ6IsUORzVsYpEdPlahXyE/jk+sR+Tg/8/G3d7QAhkaoZE+Q=="));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"v","0"));
//        Cookie cookie = new Cookie()
//
//        webClient.waitForBackgroundJavaScript(10000);
//        headMap.put("User-Agent","Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0");
//        headMap.put("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
//        headMap.put("Accept-Language","zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3");
//        headMap.put("Accept-Encoding","gzip, deflate");
//        headMap.put("Cookie","t=eb3178c67d3ac3d5eb5b0767672ebdff; cna=sIYTEF2XWG4CAXQW6RfWKi3q; " +
//                "l=Ag4O1D8zcgrVFyb5xt99DHsFfurQj9KJ; " +
//                "isg=AsHBPCnwcp1IHJ6oCw5Gg5mC0wuDSDXgT8Z37CMWvUgnCuHcaz5FsO-Imse3; " +
//                "mm-guidance3=1; cookie2=3151bb67bdfeba10a53a1042dc1cc1a0; _tb_token_=OhrHSUwviip; v=0; " +
//                "rurl=aHR0cDovL3B1Yi5hbGltYW1hLmNvbS8%2Fc3BtPWEyMzIwLjczODg3ODEuYTIxNHRyOC4xNC5XOENndkg%3D");
//        headMap.put("Connection","keep-alive");
//        headMap.put("Cache-Control","max-age=0");
//        request.setAdditionalHeaders(headMap);

        request.setCharset("UTF-8");
//        request.setProxyHost("110.75.96.108");
//        request.setProxyPort(80);
        request.setHttpMethod(HttpMethod.POST);
        TextPage page =  webClient.getPage(request);

        String content = page.getContent();
        System.out.print(content);
        String cookie2 = webClient.getCookieManager().getCookie("cookie2").getValue();
        String tbToken = webClient.getCookieManager().getCookie("_tb_token_").getValue();
        String sessionid = content.substring(content.indexOf("token")+8, content.length()-3);
        System.out.println(sessionid);

        URL link0=new URL("https://passport.alipay.com/mini_apply_st.js?site=0&token="+sessionid+"&callback=vstCallback65");
        WebRequest request0 = new WebRequest(link0);
        request0.setAdditionalHeaders(headMap);
        request0.setHttpMethod(HttpMethod.GET);
        JavaScriptPage page0 = webClient.getPage(request0);
        String regex = "vstCallback65\\((.*)\\)";
        Pattern compile = Pattern.compile(regex);
        Matcher m = compile.matcher(page0.getContent());
        String st = StringUtils.EMPTY;
        while(m.find()) {
            String group = m.group(1);
            JSONObject jsonObject = JSON.parseObject(group);
            JSONObject jsonObject0 = (JSONObject) jsonObject.get("data");
            st = (String) jsonObject0.get("st");
//            JSONObject string2Json = String2Json(group);
        }
        System.out.print(page0.getContent());

        URL link1=new URL("https://login.taobao.com/member/vst.htm?st="+st+"&params=style%3Dminisimple%26sub%3Dtrue%26TPL_username%3D"+userName+"%26loginsite%3D0%26from_encoding%3D%26not_duplite_str%3D%26guf%3D%26full_redirect%3D%26isIgnore%3D%26need_sign%3D%26sign%3D%26from%3Ddatacube%26TPL_redirect_url%3Dhttp%25253A%25252F%25252Fmofang.taobao.com%25252Fs%25252Flogin%26css_style%3D%26allp%3D&_ksTS=1404787873165_78&callback=jsonp79");
        WebRequest request1 = new WebRequest(link0);
        request1.setAdditionalHeaders(headMap);
        request1.setHttpMethod(HttpMethod.GET);
        JavaScriptPage page1 = webClient.getPage(request1);
        System.out.print(page1.getContent());

//        String searchPath0 = "https://detail.tmall.com/item.htm?spm=a230r.1.14.6.1Usm96&id=3871509989&cm_id=140105335569ed55e27b&abbucket=5";
//        URL link2 =new URL("http://pub.alimama.com/items/search.json?q="+searchPath0+"&_t=0&auctionTag=&perPageSize=40&shopTag=&t=0&_tb_token_="+sessionid+"&pvid=0");
//        WebRequest request2 = new WebRequest(link0);
//        request2.setAdditionalHeaders(headMap);
//        request2.setHttpMethod(HttpMethod.GET);
//        JavaScriptPage page2 = webClient.getPage(request2);
//
//        JSONObject jsonObject1 = JSON.parseObject(page2.getContent());
//        JSONObject jsonObject2 = (JSONObject) jsonObject1.get("data");
//        JSONArray jsonArray = (JSONArray) jsonObject2.get("pageList");
//        if(jsonArray!=null){//查到东西
//
//        }
//        System.out.print(page2.getContent());


        String domain = "pub.alimama.com";
        String itemId = "3871509989";
        String path0 = "https://item.taobao.com/item.htm?spm=a219r.lm843.14.9.rKpOhX&id=41151889034&ns=1&abbucket=5#detail";

        String regex0 = "&id=(.*)&ns";
        Pattern compile0 = Pattern.compile(regex0);
        Matcher m0 = compile0.matcher(path0);
        while(m0.find()) {
            itemId = m0.group(1);
        }
       System.out.print(itemId);

//        URL link3 = new URL("http://pub.alimama.com/common/code/getAuctionCode.json?auctionid="+itemId+"&adzoneid=58582269&siteid=15150565&scenes=1&t=1469005032011&_tb_token_="+tbToken+"&pvid=0");
        URL link3 = new URL("http://pub.alimama.com/common/code/getAuctionCode.json?auctionid=41151889034&adzoneid=58582269&siteid=15150565&scenes=1&t=1469086252162&_tb_token_=IMHEyK849jp&pvid=10_116.22.232.73_964_1469086233090");
        WebRequest request3 = new WebRequest(link3);
//        webClient.getCookieManager().addCookie(new Cookie(domain,"_tb_token","DkJKDKJkxip"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"account-path-guide-s1","true"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"alimamapw","AAZXXU5VMAEGUQACWQYECVRTU1sDW1EAWgIEBgdWCQYCXwJXAAdT"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"alimamapwag","TW96aWxsYS81LjAgKE1hY2ludG9zaDsgSW50ZWwgTWFjIE9TIFggMTAuMTE7IHJ2OjQ3LjApIEdlY2tvLzIwMTAwMTAxIEZpcmVmb3gvNDcuMA=="));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"cna","sIYTEF2XWG4CAXQW6RfWKi3q"));
        webClient.getCookieManager().addCookie(new Cookie(domain,"cookie2","3d56f09e03816096bd275daf33285195"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"cookie31","MTY3Mzg0NjgsZGRmZXllLGRkZmV5ZUAxMjYuY29tLFRC"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"cookie32","ea8904595d46979a67fea06ff31765eb"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"isg","AikpBGzOWtfChWZgowZ-O7F6O9O6cR0ol07vpMsepZBPkkmkE0Yt-BcKIo9f"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"l","AsrKo-rSDnaxe2INKmtxAu1oOr5su04V"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"login","Vq8l+KCLz3/65A=="));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"rurl","aHR0cDovL3B1Yi5hbGltYW1hLmNvbS8/c3BtPWEyMzIwLjczODg3ODEuYTIxNHRyOC4xNS45U0FybGQ="));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"t","eb3178c67d3ac3d5eb5b0767672ebdff"));
//        webClient.getCookieManager().addCookie(new Cookie(domain,"v","0"));

        request3.setHttpMethod(HttpMethod.GET);
        request3.setAdditionalHeaders(headMap);
        UnexpectedPage page3 = webClient.getPage(request3);
        System.out.print( page3.getWebResponse().getContentAsString());
        JSONObject jsonObject3 = JSON.parseObject(page3.getWebResponse().getContentAsString());
        JSONObject jsonObject4 = (JSONObject)jsonObject3.get("data");
        String productPath = (String) jsonObject4.get("clickUrl");
        System.out.print(productPath);
    }
}
